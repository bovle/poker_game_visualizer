from test import run_benchmark, run_table
from poker_game_runner.bots import randombot
from example_bots import panic_bot, odds_bot, checkmate, position_bot, odds_bot_1, odds_bot_2, odds_bot_3
import my_bot_dev
import my_bot_dev_2
import my_bot_dev_3
import my_bot_master

bots = [panic_bot, odds_bot_3, odds_bot, checkmate, position_bot, my_bot_dev, my_bot_dev_2, my_bot_master, my_bot_dev_3]
#bots = [odds_bot_2, odds_bot_1, odds_bot, odds_bot_3]
#checkmate

#run_table(bots)

run_benchmark(bots, 1000)
 
