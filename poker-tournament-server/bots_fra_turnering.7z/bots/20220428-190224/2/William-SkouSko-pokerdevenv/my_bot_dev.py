
from poker_game_runner.state import Observation
from poker_game_runner.utils import Range, HandType

class Bot:

  def __init__(self) -> None:
      self.r20 = Range("55+, A3s+, K7s+, Q8s+, J9s+, T9s, A9o+, KTo+, QJo") # top 20%
  
  def get_name(self):
      return "Williams_bot"
  
  def act(self, obs: Observation):
#    if(obs.current_round == 0):
    if(self.r20.is_hand_in_range(obs.my_hand) and obs.current_round == 0):
      return obs.get_fraction_pot_raise(1)
      
    if(obs.current_round > 0):
      if(obs.get_my_hand_type > obs.get_board_hand_type):
        return obs.get_fraction_pot_raise(obs.get_my_hand_type - obs.get_board_hand_type)
        
    for action in obs.get_actions_in_round(obs.current_round):
      if(action[1] > 1):
        if(obs.get_my_hand_type() < 2):
          return 0
    return 1
