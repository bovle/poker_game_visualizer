
from poker_game_runner.state import Observation
from poker_game_runner.utils import Range, HandType

class Bot:
  def get_name(self):
      return "Williams_giga_bot"
  
  def act(self, obs: Observation):
    if(obs.current_round == 0):
      return 1
    if(obs.get_my_hand_type() > obs.get_board_hand_type()):
      return obs.get_fraction_pot_raise(1)
