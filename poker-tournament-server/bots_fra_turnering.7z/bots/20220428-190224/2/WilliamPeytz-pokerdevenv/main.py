from test import run_benchmark, run_table
from poker_game_runner.bots import randombot
from example_bots import panic_bot, odds_bot, checkmate, position_bot, roysignaler
import my_bot_dev
import my_bot_master


bots = [position_bot, position_bot, checkmate, position_bot, randombot, position_bot, checkmate, roysignaler, my_bot_master, my_bot_dev]

#run_table(bots)

run_benchmark(bots, 30)
 
