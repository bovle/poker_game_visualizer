from test import run_benchmark, run_table
from poker_game_runner.bots import randombot
from example_bots import panic_bot, my_bot_dev_old, checkmate, position_bot, William, my_bot_dev_old_new
import my_bot_dev
import my_bot_master
import hetling_master

bots = [panic_bot, my_bot_dev_old, checkmate, position_bot, my_bot_dev, my_bot_master, William, hetling_master, my_bot_dev_old_new]

#run_table(bots)

run_benchmark(bots, 100)
 
#checkmate, position_bot, checkmate
#position_bot, randombot,