
from poker_game_runner.state import Observation
from poker_game_runner.utils import Range, HandType

class Bot:
  def __init__(self) -> None:
    self.r25 = Range("55+, A2s+, K5s+, Q8s+, J8s+, T9s, A8o+, K9o+, QTo+, JTo") # top 25%
    self.r20 = Range("55+, A3s+, K7s+, Q8s+, J9s+, T9s, A9o+, KTo+, QJo") # top 20%
    self.r16 = Range("66+, A5s+, K9s+, Q9s+, JTs, ATo+, KJo+, QJo") # 16%
    self.r10 = Range("77+, A9s+, KTs+, QJs, AJo+, KQo") # 10%
    self.r6 = Range("88+, ATs+, KJs+, AKo") # 6%
    self.r40 = Range("33+, A2s+, K2s+, Q4s+, J6s+, T7s+, 97s+, 87s, A3o+, K7o+, Q8o+, J9o+, T9o") # 40%
  def get_name(self):
      return "Oliver Kaupert"
  
  def act(self, obs: Observation):
    if obs.current_round == 0: #preflop
      return self.do_preflop(obs)
    else:
      return self.do_postflop(obs)
      
    return 0

  def do_preflop(self, obs:Observation):
    r = self.r40
    r_first = self.r10
    if not obs.can_raise():
      return 1
    if self.no_raises(obs):
      if r_fist.is_hand_in_range(obs.my_hand) and round(obs.get_max_raise()/10) > obs.get_min_raise():
        return round(obs.get_max_raise()/10)
      else:
        return 1
    elif r.is_hand_in_range(obs.my_hand) and round(obs.get_max_raise()/5) > obs.get_min_raise():
      return round(obs.get_max_raise()/5) # raise 1 pot
    else:
      return 0
    
  def do_postflop(self, obs:Observation):
    
  def no_raises(self, obs:Observation):
    raise_actions = [action_info for action_info in obs.get_actions_this_round() if action_info.action > 1]
      
    return len(raise_actions) == 0