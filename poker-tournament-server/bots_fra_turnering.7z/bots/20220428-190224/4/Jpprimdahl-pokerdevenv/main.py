from test import run_benchmark, run_table
from poker_game_runner.bots import randombot
from example_bots import panic_bot, odds_bot, checkmate, position_bot
import my_bot_dev
import my_bot_master

bots = [panic_bot, odds_bot, checkmate, position_bot, randombot, my_bot_master, odds_bot, checkmate, position_bot, my_bot_dev]

run_table(bots,runs=500)


#1v1
#run_table([my_bot_dev, odds_bot],50)
#run_benchmark(bots, 30)
 
