
from poker_game_runner.state import Observation
from poker_game_runner.utils import Range, HandType

class Bot:
  def __init__(self) -> None:
    self.r10 = Range("77+, A9s+, KTs+, QJs, AJo+, KQo")
    self.r50 = Range("22+, A2s+, K2s+, Q2s+, J2s+, T5s+, 96s+, 86s+, 75s+, A2o+, K5o+, Q7o+, J8o+, T8o+")
    self.r100 = Range("22+, A2s+, K2s+, Q2s+, J2s+, T2s+, 92s+, 82s+, 72s+, 62s+, 52s+, 42s+, 32s, A2o+, K2o+, Q2o+, J2o+, T2o+, 92o+, 82o+, 72o+, 62o+, 52o+, 42o+, 32o") # top 100%
  def get_name(self):
      return "AllInOrGoHome"
  
  def act(self, obs: Observation):
    if self.r10:
      #print(obs.my_hand)
      print("We are the top 10% We go big!")
      print(obs.my_hand())
      return obs.get_max_raise()
      
    elif self.r50:
      print("We are the top 50% follow the sheeple")
      print(obs.my_hand())
      return 1

    else:
      print("this is shit abort")
      print(obs.my_hand())
      return 0
