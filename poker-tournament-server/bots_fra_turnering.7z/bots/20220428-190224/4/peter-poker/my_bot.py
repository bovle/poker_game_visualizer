from poker_game_runner.state import Observation
from poker_game_runner.utils import Range, HandType

#docs: https://poker-game-runner.readthedocs.io/en/latest/poker_game_runner.html

class Bot:
  def __init__(self) -> None:
    self.r25 = Range("44+, A2s+, K4s+, Q6s+, J7s+, T8s+, 98s, A7o+, K9o+, QTo+, JTo") # 25%
    self.r16 = Range("66+, A5s+, K9s+, Q9s+, JTs, ATo+, KJo+, QJo") # 16%
    self.r10 = Range("77+, A9s+, KTs+, QJs, AJo+, KQo") # 10%
    self.shove = Range("TT+") # Shove range
      
  def get_name(self):
      return "GTO BOT"
  
  def is_hand_shovable(self, obs:Observation):
    return self.shove.is_hand_in_range(obs.my_hand)
  
  def is_hand_ace_or_better(self, obs:Observation):
      my_hand_type = obs.get_my_hand_type()
      return my_hand_type >= HandType.PAIR or self.is_card_rank_in_hand('A', obs.my_hand)

  def do_preflop(self, obs: Observation):
    my_stack_in_blinds = obs.player_infos[obs.my_index].stack / obs.big_blind
    active_players = len(obs.get_active_players())
    
    if (self.is_hand_shovable and active_players < 3):
      return obs.get_max_raise()
    if (self.is_hand_ace_or_better(self,obs) and my_stack_in_blinds < 20 ):
      return obs.get_max_raise()
    return 0

  def is_hand_good_enough_to_call(self, obs: Observation):
    my_hand_type = obs.get_my_hand_type
    if (my_hand_type < HandType.THREEOFAKIND and 
        my_hand_type > HandType.ONE_PAIR):
      return True
    return False
          
  def do_postflop(self, obs: Observation):
    player_count = obs.get_player_count()
    active_players = len(obs.get_active_players())
    my_hand_type = obs.get_my_hand_type
    
    if (my_hand_type >= HandType.TWOPAIR and active_players < 2):
      return obs.get_max_raise()
    if self.is_hand_good_enough_to_call(obs):
      return 1
    if (my_hand_type >= HandType.PAIR):
      return obs.get_min_raise();
    return 0
    
  def act(self, obs: Observation): 
    if obs.current_round == 0: #preflop
      return self.do_preflop(obs)
    return self.do_postflop(obs)
    # return 0 to fold, 1 to call or x to raise to x
    
    return 0