
from poker_game_runner.state import Observation
from poker_game_runner.utils import Range, HandType

class Bot:

  pot_value = 1000
  
  def get_name(self):
      return "Dain IronFoot"
  
  def act(self, obs: Observation):

    # Remmber legal actions (5 raises max)
    # Return 0 is fold
    # Return

    my_actual_hand = []
    for card in obs.my_hand:
      card = card[0]
      my_actual_hand.append(card)

    actual_board_cards = []
    for card in obs.board_cards:
      card = card[0]
      actual_board_cards.append(card)

    percentage_6 = []
    percentage_6_size = 40
    percentage_14 = []
    percentage_14_size = 35
    percentage_28 = []
    percentage_28_size = 30
    percentage_46 = []
    percentage_46_size = 25
    percentage_68 = []
    percentage_68_size = 20

    #max_bet_size = obs.stack
    
    # matches 
    if obs.current_round <= 20:
      if my_actual_hand in percentage_6:
        if obs.pot_value < percentage_6_size:
          kong = percentage_6_size
        else:
          kong = obs.get_pot_size()
      else:
        kong = 0
        
    elif obs.current_round <= 30:
      if my_actual_hand in percentage_14:
        if obs.pot_value < percentage_14_size:
          kong = percentage_14_size
        else:
          kong = obs.get_pot_size()        
      else:
        kong = 0
      
    elif obs.current_round <= 40:
      if my_actual_hand in percentage_28:
        if obs.pot_value < percentage_28_size:
          kong = percentage_28_size
        else:
          kong = obs.get_pot_size()        
      else:
        kong = 0

      
    elif obs.current_round <= 50:
      if my_actual_hand in percentage_46:
        if obs.pot_value < percentage_46_size:
          kong = percentage_46_size
        else:
          kong = obs.get_pot_size()
      else:
        kong = 0

    
    elif obs.current_round <= 60:
      if my_actual_hand in percentage_68:
        if obs.pot_value < percentage_68_size:
          kong = percentage_68_size
        else:
          kong = obs.get_pot_size()        
      else:
        kong = 0

    else:
      if my_actual_hand not in percentage_68:
        if obs.pot_value < 15:
          kong = 15
        else:
          kong = obs.get_pot_size()
      else:
        kong = 0

    print(f"My hand: {my_actual_hand}")
    print(f"Cards on the table: {actual_board_cards}")      
    return kong
