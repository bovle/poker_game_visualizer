
from poker_game_runner.state import Observation
from poker_game_runner.utils import Range, HandType
import numpy as np

class Bot:

  def __init__(self) -> None:
      self.r25 = Range("55+, A2s+, K5s+, Q8s+, J8s+, T9s, A8o+, K9o+, QTo+, JTo") # top 25%
      self.r20 = Range("55+, A3s+, K7s+, Q8s+, J9s+, T9s, A9o+, KTo+, QJo") # top 20%
      self.r16 = Range("66+, A5s+, K9s+, Q9s+, JTs, ATo+, KJo+, QJo") # 16%
      self.r10 = Range("77+, A9s+, KTs+, QJs, AJo+, KQo") # 10%
      self.r6 = Range("88+, ATs+, KJs+, AKo") # 6%
  
  
  def get_name(self):
      return "Andy_BOT"
    

  ### ACT ###
  def act(self, obs: Observation):
    if obs.current_round == 0: #preflop
      action = self.do_preflop(obs)
      return action
    else:
      action = self.do_postflop(obs)
      return action






  ### PREFLOP ###
  def do_preflop(self,obs):
    raise_actions = [action for action in obs.get_actions_this_round() if action.action > 1]
    if len(raise_actions) == 0: # Open 
      return self.do_preflop_open(obs)
    else:
      return self.do_preflop_response(obs)

  def do_preflop_open(self,obs):
    if self.r6.is_hand_in_range(obs.my_hand):
      action = self.get_raise_opening(self,obs,20)
      if action in obs.legal_actions:
        return action
    elif self.r10.is_hand_in_range(obs.my_hand):
      action = self.get_raise_opening(self,obs,15)
      if action in obs.legal_actions:
        return action
    elif self.r16.is_hand_in_range(obs.my_hand):
      action = self.get_raise_opening(self,obs,10)
      if action in obs.legal_actions:
        return action
    elif self.r20.is_hand_in_range(obs.my_hand):
      action = self.get_raise_opening(self,obs,5)
      if action in obs.legal_actions:
        return action
    elif self.r25.is_hand_in_range(obs.my_hand):
      action = self.get_raise_opening(self,obs,2)
      if action in obs.legal_actions:
        return action

    if 1 in obs.legal_actions:
      return 1
    else: 
      return 0

  def do_preflop_response(self,obs):
    
    if self.r6.is_hand_in_range(obs.my_hand):
      action = self.get_raise_opening(self,obs,20)
      if action in obs.legal_actions:
        return action
        
    elif self.r10.is_hand_in_range(obs.my_hand):
      action = self.get_raise_opening(self,obs,15)
      if action in obs.legal_actions:
        return action
        
    elif self.r16.is_hand_in_range(obs.my_hand):
      action = self.get_raise_opening(self,obs,10)
      if action in obs.legal_actions:
        return action
        
    elif self.r20.is_hand_in_range(obs.my_hand):
      action = self.get_raise_opening(self,obs,5)
      if action in obs.legal_actions:
        return action

    elif self.r25.is_hand_in_range(obs.my_hand):
      action = self.get_raise_opening(self,obs,2)
      if action in obs.legal_actions:
        return action
      
    if 1 in obs.legal_actions:
      return 1
    else: 
      return 0
    







  ### POSTFLOP ###
  def do_postflop(self,obs):
    
    for hand_card in obs.my_hand:
      for table_card in obs.board_cards:
        if self.r6.is_hand_in_range((hand_card,table_card)):
          action = self.get_raise_compared_to_players(obs,0.5)
          if action in obs.legal_actions:
              return action
            
        elif self.r10.is_hand_in_range((hand_card,table_card)):
          action = self.get_raise_compared_to_players(obs,0.3)
          if action in obs.legal_actions:
              return action

        elif self.r16.is_hand_in_range((hand_card,table_card)):
          action = self.get_raise_compared_to_players(obs,0.2)
          if action in obs.legal_actions:
              return action

        elif self.r20.is_hand_in_range((hand_card,table_card)):
          action = self.get_raise_compared_to_players(obs,0.1)
          if action in obs.legal_actions:
              return action

        elif self.r25.is_hand_in_range((hand_card,table_card)):
          action = self.get_raise_compared_to_players(obs,0.05)
          if action in obs.legal_actions:
              return action

    if 1 in obs.legal_actions:
      return 1
    else: 
      return 0

  

  def get_raise_compared_to_players(self,obs,frac):
    players = len(obs.get_active_players())
    action = obs.get_fraction_pot_raise(frac)

    return round((action*4)/players)


    
  def get_raise_opening(self,obs,size):
    call = obs.get_call_size()

    return round(call*size)
    
    