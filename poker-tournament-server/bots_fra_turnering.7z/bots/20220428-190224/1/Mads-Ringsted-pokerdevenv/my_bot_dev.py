
from poker_game_runner.state import Observation
from poker_game_runner.utils import Range, HandType
import random

class Bot:

  def __init__(self):

    self.s = Range("77+, A9s+, KTs+, QJs, AJo+, KQo")
    self.A = Range("33+, A2s+, K2s+, Q4s+, J6s+, T7s+, 97s+, 87s, A3o+, K7o+, Q8o+, J9o+")
    self.B = Range("22+, A2s+, K2s+, Q2s+, J2s+, T2s+, 94s+, 84s+, 74s+, 64s+, 54s, A2o+, K3o+, Q5o+, J7o+, T7o+, 97o")

    self.play_bluff = 0
    
    
  def get_name(self):
      return "¯\\_(ツ)_/¯"
  
  def act(self, obs: Observation):


    if self.play_bluff == 1:
      self.bluff(obs)

    elif obs.current_round == 0:
      self.pre_flop_action(obs)
    elif obs.current_round == 1:
      self.flop_action(obs)
    elif obs.current_round == 2:
      return obs.get_max_raise()
    elif obs.current_round ==3:
      return obs.get_max_raise()

    return 0 


  def pre_flop_action(self,obs: Observation):
    if self.s.is_hand_in_range(obs.my_hand()):
      print("s")
      if obs.can_raise():
        return (obs.get_max_raise() - obs.get_min_raise())//2
      else:
        return 1
    
    elif self.A.is_hand_in_range(obs.my_hand()):
      print("A")
      if obs.can_raise():
        action = random.randint(0,1)
        if action == 1:
          return obs.get_min_raise()
        else:
          return 1
    
    elif self.B.is_hand_in_range(obs.my_hand):
      print("B")
      self.play_bluff = random.randint(0,1)
      if self.play_bluff == 1:
        self.bluff(obs)
      else:
        return 1 if 1 in obs.legal_actions else 0
    return 0


  def flop_action(self, obs: Observation):

    hand = obs.get_my_hand_type().value
    board = obs.get_board_hand_type().value

    if hand >= 2 and hand > board:
      return obs.get_max_raise()

    return 1 if 1 in obs.legal_actions else 0


  def bluff(self,obs: Observation):
      if obs.can_raise():
        return obs.get_min_raise()
      else:
        return 1 if 1 in obs.legal_actions else 0
        
    
    
      
        
      
      
      
    
    
  
    

    
