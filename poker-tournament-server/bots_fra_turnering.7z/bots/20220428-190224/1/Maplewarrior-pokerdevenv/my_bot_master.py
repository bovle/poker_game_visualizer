
from poker_game_runner.state import Observation
from poker_game_runner.utils import Range, HandType
import numpy as np
"""
Observations contains all the necessary info:


Return 0 = Fold

Return 1 = Call

Return > 1 Raise

If raise > Legal actions:
    Action = Fold

If there is 15 in the pot and you raise 20, then you have raised with +5.

Cards are represented as (Rank_suit)
A hand is a tuple of the two cards, example: (Ah, 5c) = Ace of hearts and 5 of clubs.

Questions:
- Do you know which position you are in? 
Ans: Yes, my_index returns this, it is zero if you are big blind and 1 if UTG... (CHECK THIS)

"""

class Bot:
  def __init__(self) -> None:
    self.rUTG = Range("77+, A5s, A10s+, AQo+, KQs+, QJs+, J10s+,J9s, T9s, 98s")
    self.rUTGP1 = Range("77+, A5s, A10s+, AQo+, KQs+, QJs+, J10s+, J9s,T9s, 98s")
    self.rUTGP2 = Range("77+, A5s, A4s, A8s+, AJo+, KQs+, QJs+,  J10s,T9s+, 98s")
    self.rLJ = Range("55+, A2s+, AJo+, KJo+, KQs+, QJs+,  J10s+,T9s+, 108s,98s, 87s, 76s ")
    self.rHJ =  Range("44+, A2s+, A10o+, KJo+, QJo+, KQs+, QJs+,  J10s+,T9s+, 108s,98s, 87s, 76s,65s")
    self.rCO = Range("22+, A2s+, A10o+, K10o+, Q10o+, J10o+, 109s+, 98s+ 97s, 87s, 86s, 76s, 65s, 54s")
                     
    self.rBTN = Range("22+, A2s+ K3s+, Q5s+, J6s+,106s+, 96s+, ,87s, 86s, 85s, 76s, 65s, 54s, 43s, A2o+, K9o+, Q9o+, J9o+, 109o+")
    self.rSB = Range("22+, A2s+ K3s+, Q5s+, J6s+,106s+, 96s+, ,87s, 86s, 85s, 76s, 65s, 54s, 43s, A2o+, K9o+, Q9o+, J9o+, 109o+")
                     
    
  def get_name(self):
      return "Tom_Dwan_2.0"
  
  def act(self, obs: Observation):
    if obs.current_round == 0:
      return self.do_preflop(obs)
      
    else:
      self.do_post_flop(obs)
    
    
  def do_preflop(self, obs: Observation):
    raise_actions = [action for action in obs.get_actions_this_round() if action.action > 1]

    if len(raise_actions ==0):
      return self.do_preflop_open(obs)
    else:
      return self.do_preflop_response(obs)
    
      
  def do_preflop_open(self, obs: Observation):
    
    # Check if there has been no previous raise
    if obs.get_pot_size == obs.small_blind + obs.big_blind: 
    # Small blind
      if obs.my_index == 0:
        if obs.my_hand in self.rSB:
          return int(obs.get_max_raise()/3)

      # Big blind = Check (change later)
      elif obs.my_index == 1:
        return 1
        
      # UTG
      elif obs.my_index == 2:
        if obs.my_hand in self.rUTG:
          return obs.get_min_raise()
      #UTG+1
      elif obs.my_index == 3:
        if obs.my_hand in self.rUTGP1:
          return obs.get_min_raise()

      #UTG+2
      elif obs.my_index == 4:
        if obs.my_hand in self.rUTGp2:
          return obs.get_min_raise()
      #LJ
      elif obs.my_index == 5:
        if obs.my_hand in self.rLJ:
          return int(obs.get_max_raise()/8)
      #HJ
      elif obs.my_index == 6:
        if obs.my_hand in self.rHJ:
          return int(obs.get_max_raise()/7)
      #CO
      elif obs.my_index == 7:
        if obs.my_hand in self.rSB:
          return int(obs.get_max_raise()/6)
        
      #Button
      elif obs.my_index == 8:
        if obs.my_hand in self.rSB:
          return int(obs.get_max_raise()/4)
      else:
        return 1
    else:
      if obs.my_hand in self.rBHJ:
        return 1
      else: 
        return 0
        
  def do_preflop_response(self, obs:Observation):
    call_odds = obs.get_call_size() / obs.get_pot_size()
    if call_odds < 0.1:
      return 1 #call all small raises
    elif call_odds < 0.3:
      r = self.rBTN
    elif call_odds < 0.6:
      r = self.rLJ
    else:
      r = self.rUTGP1

    if r.is_hand_in_range(obs.my_hand):
      return 1
    else:
      return 0

  def do_postflop(self, obs:Observation):
    if obs.get_call_size() == 0:
      return self.do_post_flop_open(obs)
    else:
      return self.do_post_flop_response(obs)
  
  def do_post_flop_open(self, obs:Observation):
    if self.is_hand_ace_or_better(obs):
        return obs.get_fraction_pot_raise(1)

  def is_hand_ace_or_better(self, obs:Observation):
    my_hand_type = obs.get_my_hand_type()
    return my_hand_type >= HandType.PAIR or self.is_card_rank_in_hand('A', obs.my_hand)

  def is_card_rank_in_hand(self, rank, hand):
    return rank in hand[0] or rank in hand[1]

  def do_post_flop_response(self, obs: Observation):
    call_odds = obs.get_call_size() / obs.get_pot_size()
    my_hand_type = obs.get_my_hand_type()
    if call_odds < 0.1:
      return 1 #call all small raises
    elif call_odds < 0.3:
      if my_hand_type >= HandType.PAIR and my_hand_type.value > obs.get_board_hand_type().value:
        return 1
    elif call_odds < 0.6:
      if my_hand_type > HandType.PAIR and my_hand_type.value > obs.get_board_hand_type().value+1:
        return 1
    else:
      if my_hand_type > HandType.TWOPAIR and my_hand_type.value > obs.get_board_hand_type().value+1:
        return 1

    return 0
  """
  def do_postflop(self, obs: Observation):
    # p_bluff = 0.15
    ht_value = obs.get_board_hand_type().value
    
    
    if self.no_raises(obs):
      if ht_value >=1:
        return obs.get_min_raise() #attempt to steal the pot
      
    # Check if we have a "decent hand"
    elif ht_value >= 2:
      if self.no_raises(obs):
        return int(obs.get_max_raise()/5)
      else:
        return 1
    else:
      return 0
      
  def do_post_flop_open(self, obs:Observation):
    if self.is_hand_ace_or_better(obs):
        return obs.get_fraction_pot_raise(1)

  def is_hand_ace_or_better(self, obs:Observation):
    my_hand_type = obs.get_my_hand_type()
    return my_hand_type >= HandType.PAIR or self.is_card_rank_in_hand('A', obs.my_hand)

"""
