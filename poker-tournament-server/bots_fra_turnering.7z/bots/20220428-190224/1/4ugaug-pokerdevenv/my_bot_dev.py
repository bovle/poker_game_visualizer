
from poker_game_runner.state import Observation
from poker_game_runner.utils import Range, HandType
from random import randint

class Bot:
  def __init__(self):
    self.super_hand = Range("99+, AJs+, KQs, 76s, 72s-74s, AKo, Q6o, J6o, 87o")

    # Set a range for the 15%
    self.pre_flop_s15 = Range("66+, A8s+, A6s, K9s+, Q9s+, JTs, 75s, 72s-73s, ATo+, KJo+, 97o, 87o")

    self.never_play = Range("22+, A2s+, K2s+, Q2s+, J2s+, T5s+, 96s+, 86s+, 75s+, A2o+, K5o+, Q7o+, J8o+, T8o+")
  
  def get_name(self):
      return "Magnus Karlson"
  
  def act(self, obs: Observation):
    current_hand = obs.my_hand()
    player_info = obs.get_my_player_info()
    # Define some risktaking factor
    current_pocket_change = player_info.stack()
    
    current_board_stack = obs.get_pot_size()

    # Pre flop
    if obs.current_round == 0:
      do_preflop(self)

    # First post flop, 1 extra card on the deck
    if obs.current_round >= 1:
      do_postflop(self)

  def do_preflop(self, obs: Observation):
    current_hand = obs.my_hand()
    player_info = obs.get_my_player_info()
    # Define some risktaking factor
    current_pocket_change = player_info.stack()
    self.risk = randint(1,100)
    current_board_stack = obs.get_pot_size()
    # Sometimes we just go fkcing all in
    if self.risk == 100:
      return obs.get_max_raise()
    
    # If we have a super hand the risk is larger (80% of the time we raise)
    if self.super_hand.is_hand_in_range(current_hand):
      if self.risk >= 20:
        raise_factor = 1/randint(5,10)
        raise_ = raise_factor * randint(1,0.1*current_pocket_change)
        return current_board_stack + raise_
        
      else:
        return 1
      
    # If we have a somewhat good hand (top 20%)
    if self.pre_flop_s15.is_hand_in_range(current_hand) and not self.never_play.is_hand_in_range(current_hand):
      # 20% of the time we do something random even though our hand sucks (To lure out folds)
      if self.risk >= 80:
        raise_ = randint(1,0.2*current_pocket_change)
        return current_board_stack + raise_

      else:
        return 1

    # if we have a shite hand
    if not self.never_play.is_hand_in_range(current_hand):
      # We fold
      return 0

    else:
      return 1


  def do_postflop(self, obs: Observation):
    current_hand = obs.my_hand()
    player_info = obs.get_my_player_info()
    # Define some risktaking factor
    current_pocket_change = player_info.stack()
    self.risk = randint(1,100)
    current_board_stack = obs.get_pot_size()
    # if we do not have anything, but there is something on the board
    if not obs.get_my_hand_type() and obs.get_board_hand_type():
      # 20% of the time we raise, otherwise we fold
      if self.risk >= 20:
        raise_ = randint(1,0.2*current_pocket_change)
        return current_board_stack + raise_
        
      else:
        return 0
      
      # If we do have something and there is nothing on the board
      if obs.get_my_hand_type() and not obs.get_board_hand_type():
          # If we have something really good
          if obs.get_my_hand_type() in ["STRAIGHTFLUSH", "FOUROFAKIND", "FULLHOUSE"]:
            risk = randint(1,100)
            if risk >= 80:
              # all in
              return obs.get_max_raise()
            else:
              # Return a large percentage of our stack
              return 0.7 * current_pocket_change

      # if nothing on the board and nothing in our hand we check
      if not obs.get_my_hand_type() and not obs.get_board_hand_type():
        return 1    
