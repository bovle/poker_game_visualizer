
from poker_game_runner.state import Observation
from poker_game_runner.utils import Range, HandType
from test import runtable
import random

class Bot:
  def get_name(self):
      return "Monte Kalen"

  
  def __init__(self) -> None:
    self.r25 = Range("44+, A2s+, K4s+, Q6s+, J7s+, T8s+, 98s, A7o+, K9o+, QTo+, JTo") # 25%
    self.r16 = Range("66+, A5s+, K9s+, Q9s+, JTs, ATo+, KJo+, QJo") # 16%
    self.r10 = Range("77+, A9s+, KTs+, QJs, AJo+, KQo") # 10%
  
  def act(self, obs: Observation):
    win_prob = simulate(obs.my_hand, obs.board_cards, 100)

    return action

  def simulate(hand, table, n_sim, n_players):
    stack = []
    wins = []


    # Remove known cards
    for card in hand:
      stack.remove(card)

    for card in table:
      stack.remove(card)

    for i in range(n_sim):
      opponents = {i: None for i in range(n_players-1)}
      sim_stack = stack.copy()

      # Opponents draw
      for player in opponents:
        drawn_card1 = random.choice(sim_stack)
        sim_stack.remove(drawn_card1)
        drawn_card2 = random.choice(sim_stack)
        sim_stack.remove(drawn_card2)

        opponents[player] = (drawn_card1, drawn_card2)
          
      # Draw table cards
      sim_table = [card for card in table]
      for i in range(3 - len(sim_table)):
        drawn_card = random.choice(sim_stack)
        sim_stack.remove(drawn_card)
        sim_table.append(drawn_card)
      sim_table = tuple(sim_table)

      # Add win
      wins.append(check_win(hand, sim_table, opponents))
        

      
    
      
    
    # Remove known cards


    
    
      
    
    return win_prob
    


# 0 fold
# 1 call
# over 1 raise