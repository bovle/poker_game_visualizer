from poker_game_runner.state import Observation
from poker_game_runner.utils import Range, HandType

class Bot:

  def __init__(self) -> None:
    self.r20 = Range("55+, A3s+, K7s+, Q8s+, J9s+, T9s, A9o+, KTo+, QJo")  # 20%
    self.r16 = Range("66+, A5s+, K9s+, Q9s+, JTs, ATo+, KJo+, QJo") # 16%
    self.r10 = Range("77+, A9s+, KTs+, QJs, AJo+, KQo") # 10%
    self.r6 = Range("88+, ATs+, KJs+, AKo") # 6%

  
  def get_name(self):
      return "85% gætværk"
  
  def act(self, obs: Observation):

    # Hand is not in top 20 percent:
    if not self.r20.is_hand_in_range(obs.my_hand):
      return 0
      
    # Hand is in top percent, raises at preflop
    if obs.current_round == 0: #preflop
      if self.r6.is_hand_in_range(obs.my_hand):
        return obs.get_fraction_pot_raise(1.2)
      elif self.r10.is_hand_in_range(obs.my_hand):
        return obs.get_fraction_pot_raise(1)
      elif self.r16.is_hand_in_range(obs.my_hand):
        return obs.get_fraction_pot_raise(0.8)

    else:
      if self.r6.is_hand_in_range(obs.my_hand):
        return obs.get_fraction_pot_raise(0.5)
      else:
        return 1
        