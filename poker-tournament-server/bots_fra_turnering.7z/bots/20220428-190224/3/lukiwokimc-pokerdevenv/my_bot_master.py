
from poker_game_runner.state import Observation
from poker_game_runner.utils import Range, HandType
import random

class Bot:
  def get_name(self):
      return "randominator"
  
  def act(self, obs: Observation):
    return random.randint
