
from poker_game_runner.state import Observation
from poker_game_runner.utils import Range, HandType

"""
  This bot plays differently depending on the amount of players left in the hand.
  This is very important in poker as 
    more poeple = more hands that can beat your hand, 
    and less people = less hands that can beat your hand (if any).
"""

class Bot:

  def __init__(self) -> None:
    
    self.rfi1 = Range("22+, A2s+, K2s+, Q2s+, J2s+, T2s+, 92s+, 82s+, 72s+, 62s+, 52s+, 42s+, 32s, A2o+, K3o+, Q5o+, J6o+, T6o+, 96o+, 86o+, 76o, 65o, 54o, 43o")
    self.rfi2 = Range("22+, A2s+, K2s+, Q2s+, J2s+, T2s+, 92s+, 82s+, 72s+, 62s+, 52s+, 42s+, 32s, A2o+, K3o+, Q5o+, J6o+, T6o+, 96o+, 86o+, 76o, 65o, 54o, 43o")
    self.rfi3 = Range("22+, A2s+, K2s+, Q2s+, J2s+, T2s+, 92s+, 82s+, 72s+, 62s+, 52s+, 42s+, 32s, A2o+, K3o+, Q5o+, J6o+, T6o+, 96o+, 86o+, 76o, 65o, 54o, 43o")
    self.rfi4 = Range("22+, A2s+, K2s+, Q2s+, J4s+, T5s+, 95s+, 84s+, 74s+, 64s+, 54s, A2o+, K9o+, Q9o+, J9o+, T9o")
    self.rfi5 = Range("66+, A2s+, K9s+, Q9s+, JTs, ATo+, KJo+, QJo")

    self.rfi6 = Range("66+, A9s+, KTs+, QTs+, JTs, AJo+, KQo")

    self.rfi7 = Range("77+, ATs+, KTs+, QTs+, JTs, AQo+, KQo")

    self.rfi8 = Range("77+, ATs+, KTs+, QJs, AQo+")

    self.rfi9 = Range("TT+, AJs+, KQs, AQo+")

    self.rfi10 = Range("JJ+, AKs, AKo")

  def get_name(self):
      return "SimonTheMachine"
  
  def act(self, obs: Observation):
    if obs.current_round == 0: #preflop
      return self.do_preflop(obs)
    else:
      return self.do_postflop(obs)

  def do_preflop(self, obs:Observation):
    if (obs.my_index == 1):
            r = self.rfi1
    elif (obs.my_index == 2):
            r = self.rfi2
    elif (obs.my_index == 3):
            r = self.rfi3
    elif (obs.my_index == 4):
            r = self.rfi4
    elif (obs.my_index == 5):
            r = self.rfi5
    elif (obs.my_index == 6):
            r = self.rfi6
    elif (obs.my_index == 7):
            r = self.rfi7
    elif (obs.my_index == 8):
            r = self.rfi8
    elif (obs.my_index == 9):
            r = self.rfi9
    elif (obs.my_index == 10):
          r = self.rfi10

    open_raise_range = r
    if open_raise_range.is_hand_in_range(obs.my_hand):
            return obs.get_fraction_pot_raise(3)  # raise 1 pot
    else:
            return 0  

  def do_postflop(self, obs:Observation):
    active_player_count = len(obs.get_active_players())
    r = False
    my_hand_type = obs.get_my_hand_type()

    if  active_player_count <= 2: 
      if obs.get_my_hand_type >= self.is_card_rank_in_hand('A', obs.my_hand) or self.is_card_rank_in_hand('K', obs.my_hand) or self.is_card_rank_in_hand('Q', obs.my_hand): 
        r = True
    elif active_player_count == 3:
      r = self.is_hand_ace_or_king_or_better(obs)
    elif active_player_count == 4 or active_player_count == 5:
      r = my_hand_type >= HandType.PAIR and my_hand_type.value > obs.get_board_hand_type().value
    elif active_player_count == 6 or active_player_count == 7:
      r = my_hand_type >= HandType.TWOPAIR and my_hand_type.value > obs.get_board_hand_type().value+1
    else:
      r = my_hand_type >= HandType.THREEOFAKIND and my_hand_type.value > obs.get_board_hand_type().value+1

    if r:
      return obs.get_fraction_pot_raise(1) # raise 1 pot
    else:
      return 0

  def is_hand_ace_or_king_or_better(self, obs:Observation):
    my_hand_type = obs.get_my_hand_type()
    return my_hand_type >= HandType.PAIR or self.is_card_rank_in_hand('A', obs.my_hand) or self.is_card_rank_in_hand('K', obs.my_hand)

  def is_card_rank_in_hand(self, rank, hand):
    return rank in hand[0] or rank in hand[1]