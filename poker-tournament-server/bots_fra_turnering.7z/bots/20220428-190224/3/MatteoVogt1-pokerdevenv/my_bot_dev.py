
from poker_game_runner.state import Observation
from poker_game_runner.utils import Range, HandType

class Bot:
  epRangeUnopen = None
  mpRangeUnopen = None
  lpRangeUnopen = None

  def __init__(self):
    self.epRangeUnopen = Range('77+, A7s+, K9s+, QTs+, AJo+')
    self.mpRangeUnopen = Range('66+, A5s+, K9s+, Q9s+, JTs, ATo+, KJo+, QJo')
    self.lpRangeUnopen = Range('22+, A2s+, K2s+, Q2s+, J5s+, T6s+, 96s+, 87s, 76s, A2o+, K7o+, Q8o+, J9o+, T9o')
  
  def get_name(self):
      return "button++"
  
  def act(self, obs: Observation):
    N = len(obs.player_infos)
    pos = obs.my_index
    if pos >= N-3:
#      if obs.get_call_size() == obs.big_blind:
      if self.lpRangeUnopen.is_hand_in_range(obs.my_hand):
        return   min(obs.get_fraction_pot_range(5),obs.get_max_raise())
    return 0
