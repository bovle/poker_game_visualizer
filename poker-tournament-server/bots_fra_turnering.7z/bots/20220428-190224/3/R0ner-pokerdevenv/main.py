from test import run_benchmark, run_table
from poker_game_runner.bots import randombot
from example_bots import panic_bot, odds_bot, checkmate, position_bot
import my_bot_dev
import my_bot_master
import my_bot_v1
import my_bot_v2
import my_bot_v3
import my_bot_v4
import my_bot_v5

#bots = [panic_bot, odds_bot, checkmate, position_bot, randombot, panic_bot, odds_bot, checkmate, position_bot, my_bot_dev]
#bots = [odds_bot, odds_bot, checkmate, checkmate, position_bot, position_bot, my_bot_v1, my_bot_v1, randombot]
bots = [my_bot_v3, my_bot_v5, checkmate, checkmate,  my_bot_v5, my_bot_v3, position_bot, position_bot]
unique_bots = set([bot.Bot().get_name() for bot in bots])
#run_table(bots)


data = run_benchmark(bots, 400)

bot_results = {bot: 0 for bot in unique_bots}
for result in data:
  name = result['name']
  wins = result['wins']
  bot_results[name] += wins

print(bot_results)