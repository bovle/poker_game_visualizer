
from poker_game_runner.state import Observation
from poker_game_runner.utils import Range, HandType

class Bot:
  """Combine position bot and checkmate bot"""
  
  def get_name(self):
      return "v2_bot"

  def act(self, obs: Observation):
    if self.no_raises(obs):
      return obs.get_min_raise() #attempt to steal the pot
    if obs.my_hand >= HandType.PAIR:
      return obs.get_my_player_info.stack
    else:
      return 1