
from poker_game_runner.state import Observation
from poker_game_runner.utils import Range, HandType

class Bot:
  def get_name(self):
      return "NEW BOT"
  
  def act(self, obs: Observation):
    return 0
