
from poker_game_runner.state import Observation
from poker_game_runner.utils import Range, HandType

class Bot:
  def get_name(self):
      return "github account :)"
  
  def act(self, obs: Observation):
    return 0
